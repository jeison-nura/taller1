/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.konradlorenz.cadenahotelera.dto;

import co.edu.konradlorenz.cadenahotelera.entities.CiudadEntity;
import co.edu.konradlorenz.cadenahotelera.entities.HotelEntity;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author CISCO
 */
public class HotelDTO {

    private Long id;
    private String nom_hotel;
    private long num_habitaciones;
    private CiudadDTO ciudad;
    private long val_estrellas;

    public HotelDTO() {
    }

    public HotelDTO(HotelEntity hotelEntity) {
        this.id = hotelEntity.getCodigo_hotel();
        this.nom_hotel = hotelEntity.getNombre_hotel();
        this.num_habitaciones = hotelEntity.getNumero_habitaciones();
        this.val_estrellas = hotelEntity.getValoracion_hotel();

        if (hotelEntity.getCiudadEntity() != null) {
            this.ciudad = new CiudadDTO(hotelEntity.getCiudadEntity());
        }
    }

    public HotelEntity toEntity() {
        
        HotelEntity hotelEntity = new HotelEntity();

        hotelEntity.setCodigo_hotel(this.id);
        hotelEntity.setNombre_hotel(this.nom_hotel);
        hotelEntity.setNumero_habitaciones(this.num_habitaciones);
        hotelEntity.setValoracion_hotel(this.val_estrellas);

        if (this.ciudad != null) {
            CiudadEntity ciudadEntidad = new CiudadEntity();
            ciudadEntidad.setCodigo_ciudad(this.ciudad.getId());
            ciudadEntidad.setNombre_ciudad(this.ciudad.getNom_ciudad());

            hotelEntity.setCiudadEntity(ciudadEntidad);
        }

        return hotelEntity;

    }

    public  List<HotelDTO> toHotelList(List<HotelEntity> hotelList) {

        List<HotelDTO> listaHotelDTO = new ArrayList<>();

        for (int i = 0; i < hotelList.size(); i++) {
            listaHotelDTO.add(new HotelDTO(hotelList.get(i)));
        }
        
        return listaHotelDTO;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom_hotel() {
        return nom_hotel;
    }

    public void setNom_hotel(String nom_hotel) {
        this.nom_hotel = nom_hotel;
    }

    public long getNum_habitaciones() {
        return num_habitaciones;
    }

    public void setNum_habitaciones(long num_habitaciones) {
        this.num_habitaciones = num_habitaciones;
    }

    public CiudadDTO getCiudad() {
        return ciudad;
    }

    public void setCiudad(CiudadDTO ciudad) {
        this.ciudad = ciudad;
    }

    public long getVal_estrellas() {
        return val_estrellas;
    }

    public void setVal_estrellas(long val_estrellas) {
        this.val_estrellas = val_estrellas;
    }

}
