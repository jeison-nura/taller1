/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.konradlorenz.cadenahotelera.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author jeison
 */
/**
 * Modificado por:
 *
 * @author Bryan el dia 22/05/2018
 */
@Entity
public class HotelEntity implements Serializable {

    /**
     * Atributo estático para el manejo de versiones de la entidad
     */
    private final static long serialVersionUID = 1L;

    /**
     * Llave primaria de la entidad hotel
     */
    @Id
    @Column(name = "cod_hotel", nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long codigo_hotel;

    /**
     * Variable que almacena el nombre del hotel
     */
    @Column(name = "nom_hotel", nullable = false)
    private String nombre_hotel;

    /**
     * Variable que contiene el numero de habitaciones
     */
    @Column(name = "num_habitaciones", nullable = false)
    private long numero_habitaciones;

    /**
     * Variable que guarda la calificacion del hotel
     */
    @Column(name = "val_estrellas", nullable = false)
    private long valoracion_hotel;

    /**
     * Atributo que maneja la relación con la entidad Ciudad.
     */
    @ManyToOne
    @JoinColumn(name = "cod_ciudad")
    private CiudadEntity ciudadEntity;

    public long getCodigo_hotel() {
        return codigo_hotel;
    }

    public void setCodigo_hotel(long codigo_hotel) {
        this.codigo_hotel = codigo_hotel;
    }

    public String getNombre_hotel() {
        return nombre_hotel;
    }

    public void setNombre_hotel(String nombre_hotel) {
        this.nombre_hotel = nombre_hotel;
    }

    public long getNumero_habitaciones() {
        return numero_habitaciones;
    }

    public void setNumero_habitaciones(long numero_habitaciones) {
        this.numero_habitaciones = numero_habitaciones;
    }

    public long getValoracion_hotel() {
        return valoracion_hotel;
    }

    public void setValoracion_hotel(long valoracion_hotel) {
        this.valoracion_hotel = valoracion_hotel;
    }

    public CiudadEntity getCiudadEntity() {
        return ciudadEntity;
    }

    public void setCiudadEntity(CiudadEntity ciudadEntity) {
        this.ciudadEntity = ciudadEntity;
    }

}
