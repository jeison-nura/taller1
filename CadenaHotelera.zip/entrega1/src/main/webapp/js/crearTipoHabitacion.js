(function ($) {
    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageUrl = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageUrl.split('&'),
                sParameterName,
                i;
        for (var i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : sParameterName[1];
            }
        }
    };

    if (getUrlParameter('id')) {
        $.ajax({
            url: '/entrega1/api/tipohabitacion/' + getUrlParameter('id'),
            contentType: 'application/json',
            method: 'GET',
            dataType: 'json'
        }).done(function (data) {
            var nombre_tipo_habitacion = $('#nombre_tipo_habitacion').val(data.nombre_tipo_habitacion);
            var precio_tipo_habitacion = $('#precio_tipo_habitacion').val(data.precio_tipo_habitacion);

            var id = data.id;
            $('#botonCrear').text('Actualizar Tipos de Habitacion').click(function (event) {
                var nombre_tipo_habitacion = $('#nombre_tipo_habitacion').val();
                var precio_tipo_habitacion = $('#precio_tipo_habitacion').val();

                $.ajax({
                    url: '/entrega1/api/tipohabitacion/' + id,
                    contentType: 'application/json',
                    data: JSON.stringify({
                        nombre_tipo_habitacion: nombre_tipo_habitacion,
                        precio_tipo_habitacion: precio_tipo_habitacion,
                        id: id
                    }),
                    method: 'PUT',
                    dataType: 'json'
                }).done(function (data) {
                    window.location.href = '/entrega1/mostrarTipoHabitacion.html';
                }).fail(function (xhr, status, error) {
                    console.log(error);
                });
            });
        }).fail(function (xhr, status, error) {
            console.log(error);
        });
    } else {
        $('#botonCrear').click(function (event) {
            var nombre_tipo_habitacion = $('#nombre_tipo_habitacion').val();
            var precio_tipo_habitacion = $('#precio_tipo_habitacion').val();


            var idd = Math.floor(Math.random() * (8000000 - 30)) + 30;

            $.ajax({
                url: '/entrega1/api/tipohabitacion',
                contentType: 'application/json',
                data: JSON.stringify({
                    id: idd,
                    nombre_tipo_habitacion: nombre_tipo_habitacion,
                    precio_tipo_habitacion:precio_tipo_habitacion
                }),
                method: 'POST',
                dataType: 'json'
            }).done(function (data) {
                window.location.href = '/entrega1/mostrarTipoHabitacion.html';
            }).fail(function (xhr, status, error) {
                console.log(error);
            });
        });
    }
})(jQuery);